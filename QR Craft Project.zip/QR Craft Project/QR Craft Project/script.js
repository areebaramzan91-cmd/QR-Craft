// --- PAGE ROUTING SYSTEM ---
// function jo pages ko hide aur show karegi
function goToPage(pageId) {
    // Pehle saare pages ko select karo aur hide kardo
    document.getElementById('page-home').classList.add('hidden');
    document.getElementById('page-url').classList.add('hidden');
    document.getElementById('page-text').classList.add('hidden');
    document.getElementById('page-wifi').classList.add('hidden');

    // Ab jo page user ne click kiya hai, uski hidden class hata do
    document.getElementById('page-' + pageId).classList.remove('hidden');
    
    // Page open hone par hamesha screen top par chali jaye
    window.scrollTo({ top: 0, behavior: 'smooth' });
}


// --- 1. GENERATE URL QR CODE ---
function makeUrlQR() {
    var textInput = document.getElementById('url-input').value.trim();
    var qrColor = document.getElementById('url-color').value;
    var bgColor = document.getElementById('url-bg').value;
    var outputBox = document.getElementById('url-output-box');

    // Input Validation
    if (textInput == "") {
        alert("Please enter a valid website URL address first!");
        return;
    }

    // Output box mein naya layout insert karna canvas ke sath
    outputBox.innerHTML = `
        <div class="space-y-4">
            <p class="text-xs text-[#ccff00]">✔ QR Code Generated Successfully</p>
            <div class="p-3 inline-block rounded-xl" style="background-color: ${bgColor};">
                <canvas id="url-canvas"></canvas>
            </div>
            <button onclick="downloadQR('url-canvas')" class="w-full bg-white text-black font-bold text-xs py-3 rounded-xl hover:bg-gray-200">
                Download PNG Image
            </button>
        </div>
    `;

    // Library run karke QR canvas par print karna
    new QRious({
        element: document.getElementById('url-canvas'),
        value: textInput,
        size: 180,
        foreground: qrColor,
        background: bgColor,
        level: 'H'
    });
}


// --- 2. GENERATE TEXT QR CODE ---
function makeTextQR() {
    var textInput = document.getElementById('text-input').value.trim();
    var qrColor = document.getElementById('text-color').value;
    var bgColor = document.getElementById('text-bg').value;
    var outputBox = document.getElementById('text-output-box');

    if (textInput == "") {
        alert("Please type some text information!");
        return;
    }

    outputBox.innerHTML = `
        <div class="space-y-4">
            <p class="text-xs text-[#ccff00]">✔ QR Code Generated Successfully</p>
            <div class="p-3 inline-block rounded-xl" style="background-color: ${bgColor};">
                <canvas id="text-canvas"></canvas>
            </div>
            <button onclick="downloadQR('text-canvas')" class="w-full bg-white text-black font-bold text-xs py-3 rounded-xl hover:bg-gray-200">
                Download PNG Image
            </button>
        </div>
    `;

    new QRious({
        element: document.getElementById('text-canvas'),
        value: textInput,
        size: 180,
        foreground: qrColor,
        background: bgColor,
        level: 'H'
    });
}


// --- 3. GENERATE WIFI QR CODE ---
function makeWifiQR() {
    var ssid = document.getElementById('wifi-ssid').value.trim();
    var pass = document.getElementById('wifi-pass').value.trim();
    var qrColor = document.getElementById('wifi-color').value;
    var bgColor = document.getElementById('wifi-bg').value;
    var outputBox = document.getElementById('wifi-output-box');

    if (ssid == "") {
        alert("WiFi Network Name (SSID) is required!");
        return;
    }

    // Wifi QR rules formatting: WIFI:S:Name;T:WPA;P:Password;;
    var wifiPayload = "WIFI:S:" + ssid + ";T:WPA;P:" + pass + ";;";

    outputBox.innerHTML = `
        <div class="space-y-4">
            <p class="text-xs text-[#ccff00]">✔ WiFi QR Code Ready</p>
            <div class="p-3 inline-block rounded-xl" style="background-color: ${bgColor};">
                <canvas id="wifi-canvas"></canvas>
            </div>
            <button onclick="downloadQR('wifi-canvas')" class="w-full bg-white text-black font-bold text-xs py-3 rounded-xl hover:bg-gray-200">
                Download PNG Image
            </button>
        </div>
    `;

    new QRious({
        element: document.getElementById('wifi-canvas'),
        value: wifiPayload,
        size: 180,
        foreground: qrColor,
        background: bgColor,
        level: 'H'
    });
}


// --- 4. IMAGE DOWNLOAD MECHANISM ---
// Function jo canvas se image read karke direct folder mein save karegi
function downloadQR(targetCanvasId) {
    var activeCanvas = document.getElementById(targetCanvasId);
    var imageUri = activeCanvas.toDataURL("image/png");
    
    var tempLink = document.createElement('a');
    tempLink.href = imageStream = imageUri;
    tempLink.download = "My_QR_Code.png";
    
    document.body.appendChild(tempLink);
    tempLink.click();
    document.body.removeChild(tempLink);
}
